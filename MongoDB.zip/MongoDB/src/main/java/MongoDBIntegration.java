import com.mongodb.client.MongoClients;

import com.mongodb.client.MongoClient;

import com.mongodb.client.MongoDatabase;

import com.mongodb.client.MongoCollection;

import org.bson.Document;










public class MongoDBIntegration {

    public static void main(String[] args) {

        // Criar um cliente MongoDB

        MongoClient mongoClient = MongoClients.create("mongodb+srv://vinizada:root@showbts.jjyhx.mongodb.net/?retryWrites=true&w=majority&appName=ShowBts");



        // Selecionar o banco de dados

        MongoDatabase database = mongoClient.getDatabase("btsShows");



        // Selecionar a coleção

        MongoCollection<Document> collection = database.getCollection("shows");



        // Inserir um documento na coleção

        Document show = new Document("show_id", 1)

                .append("location", "Seoul")

                .append("date", "2023-09-25")

                .append("available_tickets", 100000);

        collection.insertOne(show);



        // Exibir o documento inserido

        for (Document doc : collection.find()) {

            System.out.println(doc.toJson());

        }



        // Fechar o cliente MongoDB

        mongoClient.close();

    }


}